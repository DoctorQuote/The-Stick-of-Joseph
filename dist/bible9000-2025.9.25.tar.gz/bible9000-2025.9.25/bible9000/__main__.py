try:
    from bible9000.main import mainloop
    mainloop()
except Exception as ex:
    print(ex)
exit(0)

